function openMenu() {
    document.querySelector('.ul').classList.add('open');
}

function closeMenu() {
    document.querySelector('.ul').classList.remove('open');
}

document.getElementById('messageform').addEventListener('submit', async (e) => {
  e.preventDefault();

  const nome = document.getElementById('nome').value;
  const email = document.getElementById('email').value;
  const mensagem = document.getElementById('mensagem').value;

  try {
      const response = await fetch('http://localhost:3000/contato', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
          },
          body: JSON.stringify({ nome, email, mensagem }),
      });

      if (response.ok) {
          alert('Mensagem enviada com sucesso!');
          document.getElementById('messageform').reset();
      } else {
          alert('Erro ao enviar a mensagem. Tente novamente.');
      }
  } catch (error) {
      console.error('Erro:', error);
      alert('Erro ao enviar a mensagem. Verifique a conexão com o servidor.');
  }
});
