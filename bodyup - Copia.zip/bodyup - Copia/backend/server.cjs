const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

// Configuração do CORS
app.use(cors());

// Middleware para processar JSON
app.use(bodyParser.json());

// Conectar ao MongoDB
mongoose
    .connect('mongodb+srv://lukinhaslimaa9:bWtLNqCUuibpBPae@cluster0.xubtr.mongodb.net/')
    .then(() => console.log('Conectado ao MongoDB'))
    .catch((err) => console.error('Erro ao conectar ao MongoDB:', err));


// Definir modelo de dados (schema)
const ContatoSchema = new mongoose.Schema({
    nome: { type: String, required: true },
    email: { type: String, required: true },
    mensagem: { type: String, required: true },
    data: { type: Date, default: Date.now },
});

const Contato = mongoose.model('Contato', ContatoSchema);

// Rota para salvar contato
app.post('/contato', async (req, res) => {
    try {
        const novoContato = new Contato(req.body);
        await novoContato.save();
        res.status(201).json({ message: 'Mensagem enviada com sucesso!' });
    } catch (error) {
        res.status(400).json({ error: 'Erro ao enviar a mensagem!' });
    }
});

// Iniciar o servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
