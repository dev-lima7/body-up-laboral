// routes/messageRoutes.js
import express from 'express';
import { createMessage } from './controllers/messageController.js';

const router = express.Router();

// Rota para salvar mensagens
router.post('/contato/', createMessage);

export default router;
